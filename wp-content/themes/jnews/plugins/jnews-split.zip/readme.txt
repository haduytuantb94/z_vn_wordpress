Change Log :

== 2.0.0 ==
- [IMPROVEMENT] Compatible with JNews v2.0.0

== 1.1.0 ==
- [IMPROVEMENT] Make jnews split compatible with php 7.1

== 1.0.2 ==
- [IMPROVEMENT] Prevent plugin conflict by changing ajax_url variable name

== 1.0.1 ==
- [BUG] Fix issue when JNews - Autoload used along with JNews - Split
- [IMPROVEMENT] Split post to scroll into split post content when next page clicked on normal mode
