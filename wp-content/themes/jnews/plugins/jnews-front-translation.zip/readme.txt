Change Log :

== 2.0.3 ==
- [BUG] Fix get plugin data issue

== 2.0.2 ==
- [IMPROVEMENT] Add frontend string translation for account page
- [BUG] Fix version issue on frontend translation dashboard

== 2.0.1 ==
- [IMPROVEMENT] Add frontend translation mobile truncate

== 2.0.0 ==
- [IMPROVEMENT] Compatible with JNews v2.0.0

== 1.0.4 ==
- [IMPROVEMENT] Add string translation for Telegram social icon

== 1.0.3 ==
- [IMPROVEMENT] Add string translation for StumbleUpon social icon

== 1.0.2 ==
- [IMPROVEMENT] Add string translation for Hatena share button

== 1.0.1 ==
- [BUG] Fix issue on front-end translation

== 1.0.0 ==
- First Release