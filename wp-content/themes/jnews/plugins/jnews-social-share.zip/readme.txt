Change Log :

== 2.0.2 ==
- [IMPROVEMENT] Add Facebook Access Token generator for Facebook social share counter

== 2.0.1 ==
- [BUG] Fixed ajax view and share counter issue

== 2.0.0 ==
- [IMPROVEMENT] Compatible with JNews v2.0.0

== 1.1.0 ==
- Provide ability to update Post Count & Share update even when Cache plugin activated
- Fix module query for php version 7.1

== 1.0.3 ==
- [IMPROVEMENT] Add Facebook Access Token for Facebook social share counter

== 1.0.2 ==
- [BUG] Fix number format issue

== 1.0.1 ==
- [IMPROVEMENT] Add Line and Hatena share button

== 1.0.0 ==
- First Release