Change Log :

== 2.0.2 ==
- [BUG] Fix undefined label index issue on account page

== 2.0.1 ==
- [IMPROVEMENT] Use modified date instead creation date on post meta date

== 2.0.0 ==
- [IMPROVEMENT] Compatible with JNews v2.0.0

== 1.0.3 ==
- [IMPROVEMENT] Add new archive template for liked and disliked post
- [BUG] Fix issue login form not showing when using like

== 1.0.2 ==
- [IMPROVEMENT] Prevent plugin conflict by changing ajax_url variable name

== 1.0.1 ==
- [BUG] Fix undefined variable issue

== 1.0.0 ==
- First Release