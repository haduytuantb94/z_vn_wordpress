Change Log :

== 2.0.1 ==
- [IMPROVEMENT] JNews speed now can clear cache on from multisite


== 2.0.0 ==
- [IMPROVEMENT] Compatible with JNews v2.0.0

== 1.0.2 ==
- [BUG] Fix issue additional css not loaded when using jnews speed

== 1.0.1 ==
- [IMPROVEMENT] Better handling for dynamic style
- [IMPROVEMENT] Add an option to load jQuery early

== 1.0.0 ==
- First Release