(function($){
	
	"use strict";

	var $container = $('.jeg_post_editor');

	function multiselect_control()
	{
		var $multiselect = $container.find('.multiselect-field');

        $multiselect.each(function()
        {
            if ( $(this).hasClass('selectized') ) 
            {
                // do nothing
            } else {
                var $parent = $(this).parent();
                var options = $parent.find('.data-option');

                if(options.length)
                {
                    options = JSON.parse(options.text());

                    $(this).selectize({
                        plugins: ['drag_drop', 'remove_button'],
                        options: options,
                        persist: true,
                        create: false,
                        hideSelected: true,
                        valueField: 'value',
                        labelField: 'text',
                        render: {
                            option: function(item, escape) {
                                return '<div class="' + item.class + '"><span>' + item.text + '</span></div>';
                            }
                        }
                    });
                }
            }
        });
	}

	function multiajax_control()
	{
		var $multiajax = $container.find('.multiajax-field');

        $multiajax.each(function()
        {
            if ( $(this).hasClass('selectized') ) 
            {
                // do nothing
            } else {
                var $this           = $(this),
                    $parent         = $this.parent(),
                    options         = $parent.find('.data-option'),
                    term			= $this.attr('name'),
                    action			= false,
                    ajax_load       = false;

                    if ( term == 'tag' ) 
                    {
                    	action = 'jeg_find_post_tag';
                    }

                    if ( $this.hasClass('jeg-ajax-load') ) 
                    {
                        ajax_load = true;
                    }

                if(options.length)
                {
                    options = JSON.parse(options.text());

                    $(this).selectize({
                        plugins: ['drag_drop', 'remove_button'],
                        options: options,
                        persist: true,
                        create: false,
                        hideSelected: true,
                        valueField: 'value',
                        labelField: 'text',
                        render: {
                            option: function(item, escape) 
                            {
                                var text = item.text;
                                if ( ajax_load ) 
                                {
                                    if ( text === undefined ) 
                                    {
                                        return '<div><span>' + item.value + '</span></div>';
                                    } else {
                                        return '<div><span>' + text + '</span></div>';
                                    }
                                } else {
                                    return '<div class="' + item.class + '"><span>' + item.text + '</span></div>';
                                }
                            }
                        },
                        load: function(query, callback) 
                        {
                            if ( ajax_load ) 
                            {
                                if (!query.length || query.length < 3) return callback();
                                $.ajax({
                                    url: ajaxurl,
                                    type: 'POST',
                                    dataType: 'json',
                                    data: {
                                        'string' : encodeURIComponent(query),
                                        'action'  : action
                                    },
                                    error: function() {
                                        callback();
                                    },
                                    success: function(res) {
                                        callback(res);
                                    }
                                });
                            }
                        }
                    });
                }
            }
        });
	}

	function post_format()
	{
		$container.find('.format-nav li a').each( function()
		{
			var element = $(this);

			if ( element.hasClass('active') ) 
			{
				if ( element.data('type') == 'video' ) 
				{
					$container.find('input[name="video"]').fadeIn('fast');
				} 
				else if ( element.data('type') == 'image' ) 
				{
					$container.find('input[name="image"]').fadeIn('fast');
				} else {
					$container.find('input[name="gallery"]').fadeIn('fast');
				}
			}
		});

		$container.on('click', '.format-nav li a', function(e)
		{
			e.preventDefault();

			var element = $(this);

			if ( element.hasClass('active') ) 
			{
				// do nothing
			} else {
				$container.find('.format-nav li a').removeClass('active');
				element.addClass('active');
			}

			$container.find('.format-field input, .format-field .jeg_upload_wrapper').css({
				'display' : 'none'
			});

			if ( element.data('type') == 'video' ) 
			{
				$container.find('input[name="format"]').val('video');
				$container.find('input[name="video"]').fadeIn('fast');
			} 
			else if ( element.data('type') == 'image' ) 
			{
				$container.find('input[name="format"]').val('image');
				$container.find('#featured_image').fadeIn('fast');
			} else {
				$container.find('input[name="format"]').val('gallery');
				$container.find('#featured_image_gallery').fadeIn('fast');
			}
		});
	}

    function post_list_filter()
    {
        $('.jeg_post_list_filter select[name="post-list-filter"]').on('change', function()
        {
            var order = $(this).val(),
                url   = $('input[name="current-page-url"]').val();

            if ( url.indexOf('?') > -1 )
            {
               url += '&order=' + order;
            }else{
               url += '?order=' + order;
            }
            window.location.href = url;
        });
    }

	function dispatch()
	{
		multiselect_control();
		multiajax_control();
		post_format();
        post_list_filter();
	}

	$(document).ready(function()
	{
		dispatch();
	});

})(jQuery);